import express from 'express'
const router = express.Router();

const repairController = require("./repair.controller");

// Create Repair Request
router.post("/request", repairController.createRepair);

// Get All Repair Requests
router.get("/", repairController.getAllRepairs);

// Get Repair By Id
router.get("/:id", repairController.getRepairById);

// Get Repairs By User
router.get("/user/:userId", repairController.getRepairsByUser);

// Get Repairs By Product
router.get("/product/:productId", repairController.getRepairsByProduct);

// Update Repair
router.put("/:id", repairController.updateRepair);

// Update Repair Status
router.patch("/:id/status", repairController.updateRepairStatus);

// Mark Repair Delivered
router.patch("/:id/delivered", repairController.markDelivered);

// Delete Repair
router.delete("/:id", repairController.deleteRepair);

export default router;