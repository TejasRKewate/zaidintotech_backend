const Joi = require("joi");

// Create Repair Validation
const createRepairValidation = Joi.object({
  user: Joi.string()
    .required()
    .messages({
      "string.empty": "User is required.",
      "any.required": "User is required.",
    }),

  product: Joi.string()
    .required()
    .messages({
      "string.empty": "Product is required.",
      "any.required": "Product is required.",
    }),

  issueDescription: Joi.string()
    .trim()
    .min(5)
    .max(500)
    .required()
    .messages({
      "string.empty": "Issue description is required.",
      "string.min": "Issue description must be at least 5 characters.",
      "string.max": "Issue description cannot exceed 500 characters.",
      "any.required": "Issue description is required.",
    }),

  estimatedCompletionDate: Joi.date().optional(),

  repairCost: Joi.number()
    .min(0)
    .default(0)
    .messages({
      "number.base": "Repair cost must be a number.",
      "number.min": "Repair cost cannot be negative.",
    }),

  technicianName: Joi.string()
    .trim()
    .allow("")
    .max(100),

  remarks: Joi.string()
    .trim()
    .allow("")
    .max(500),

  status: Joi.string()
    .valid(
      "Received",
      "In Progress",
      "Completed",
      "Cancelled"
    )
    .optional(),
});

// Update Repair Validation
const updateRepairValidation = Joi.object({
  issueDescription: Joi.string()
    .trim()
    .min(5)
    .max(500),

  estimatedCompletionDate: Joi.date(),

  repairCost: Joi.number().min(0),

  technicianName: Joi.string()
    .trim()
    .allow("")
    .max(100),

  remarks: Joi.string()
    .trim()
    .allow("")
    .max(500),

  status: Joi.string().valid(
    "Received",
    "In Progress",
    "Completed",
    "Cancelled"
  ),

  isDelivered: Joi.boolean(),
});

// Update Status Validation
const updateRepairStatusValidation = Joi.object({
  status: Joi.string()
    .valid(
      "Received",
      "In Progress",
      "Completed",
      "Cancelled"
    )
    .required()
    .messages({
      "any.required": "Status is required.",
    }),
});

module.exports = {
  createRepairValidation,
  updateRepairValidation,
  updateRepairStatusValidation,
};