const repairService = require("./repair.service");

// Create Repair Request
const createRepair = async (req, res, next) => {
  try {
    const repair = await repairService.createRepair(req.body);

    return res.status(201).json({
      success: true,
      message: "Repair request created successfully.",
      data: repair,
    });
  } catch (error) {
    next(error);
  }
};

// Get All Repair Requests
const getAllRepairs = async (req, res, next) => {
  try {
    const repairs = await repairService.getAllRepairs();

    return res.status(200).json({
      success: true,
      count: repairs.length,
      data: repairs,
    });
  } catch (error) {
    next(error);
  }
};

// Get Repair By Id
const getRepairById = async (req, res, next) => {
  try {
    const repair = await repairService.getRepairById(req.params.id);

    return res.status(200).json({
      success: true,
      data: repair,
    });
  } catch (error) {
    next(error);
  }
};

// Get Repairs By User
const getRepairsByUser = async (req, res, next) => {
  try {
    const repairs = await repairService.getRepairsByUser(req.params.userId);

    return res.status(200).json({
      success: true,
      count: repairs.length,
      data: repairs,
    });
  } catch (error) {
    next(error);
  }
};

// Get Repairs By Product
const getRepairsByProduct = async (req, res, next) => {
  try {
    const repairs = await repairService.getRepairsByProduct(
      req.params.productId
    );

    return res.status(200).json({
      success: true,
      count: repairs.length,
      data: repairs,
    });
  } catch (error) {
    next(error);
  }
};

// Update Repair Details
const updateRepair = async (req, res, next) => {
  try {
    const repair = await repairService.updateRepair(
      req.params.id,
      req.body
    );

    return res.status(200).json({
      success: true,
      message: "Repair updated successfully.",
      data: repair,
    });
  } catch (error) {
    next(error);
  }
};

// Update Repair Status
const updateRepairStatus = async (req, res, next) => {
  try {
    const { status } = req.body;

    const repair = await repairService.updateRepairStatus(
      req.params.id,
      status
    );

    return res.status(200).json({
      success: true,
      message: "Repair status updated successfully.",
      data: repair,
    });
  } catch (error) {
    next(error);
  }
};

// Mark Repair Delivered
const markDelivered = async (req, res, next) => {
  try {
    const repair = await repairService.markDelivered(req.params.id);

    return res.status(200).json({
      success: true,
      message: "Repair marked as delivered successfully.",
      data: repair,
    });
  } catch (error) {
    next(error);
  }
};

// Delete Repair Request
const deleteRepair = async (req, res, next) => {
  try {
    await repairService.deleteRepair(req.params.id);

    return res.status(200).json({
      success: true,
      message: "Repair request deleted successfully.",
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createRepair,
  getAllRepairs,
  getRepairById,
  getRepairsByUser,
  getRepairsByProduct,
  updateRepair,
  updateRepairStatus,
  markDelivered,
  deleteRepair,
};