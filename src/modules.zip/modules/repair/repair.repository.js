const Repair = require('./repair.model')

//create Repair Request 
const createRepair=async(data)=>{
    return await Repair.create(data)
}

//get Repair by id 
const getRepairById = async(id)=>{
    return await Repair.findById(id)
    .populate('user').populate("product")
}

//get all repair
const getAllRepairs = () =>{
    return await Repair.find()
    .populate("user").populate("product")
    .sort({createdAt:-1})
}

//get repair by user
const getRepairByUser = async(userId) =>{
    return await Repair.find({userID}).
    populate("user").sort({createdAt:-1})
}


// Get Repairs By Product
const getRepairsByProduct = async (productId) => {
  return await Repair.find({ product: productId })
    .populate("user")
    .sort({ createdAt: -1 });
};

// 
// Update Repair Status
const updateRepairStatus = async (id, status) => {
  return await Repair.findByIdAndUpdate(
    id,
    { status },
    {
      new: true,
      runValidators: true,
    }
  );
};

// Delete Repair
const deleteRepair = async (id) => {
  return await Repair.findByIdAndDelete(id);
};

module.exports = {
  createRepair,
  getRepairById,
  getAllRepairs,
  getRepairsByUser,
  getRepairsByProduct,
  updateRepair,
  updateRepairStatus,
  markDelivered,
  deleteRepair,
};