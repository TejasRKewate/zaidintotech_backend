const mongoose = require("mongoose");

const repairSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Product",
      required: true,
    },

    issueDescription: {
      type: String,
      required: true,
      trim: true,
    },

    status: {
      type: String,
      enum: [
        "Received",
        "In Progress",
        "Completed",
        "Cancelled",
      ],
      default: "Received",
    },

    estimatedCompletionDate: {
      type: Date,
    },

    repairCost: {
      type: Number,
      default: 0,
      min: 0,
    },

    technicianName: {
      type: String,
      trim: true,
      default: "",
    },

    remarks: {
      type: String,
      trim: true,
      default: "",
    },

    isDelivered: {
      type: Boolean,
      default: false,
    },

    deliveredAt: {
      type: Date,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Repair", repairSchema);