const repairRepository = require("./repair.repository");

// Create Repair Request
const createRepair = async (repairData) => {
  const {
    user,
    product,
    issueDescription,
    estimatedCompletionDate,
    repairCost,
    technicianName,
    remarks,
  } = repairData;

  const repair = await repairRepository.createRepair({
    user,
    product,
    issueDescription,
    estimatedCompletionDate,
    repairCost: repairCost || 0,
    technicianName: technicianName || "",
    remarks: remarks || "",
  });

  return repair;
};

// Get Repair By Id
const getRepairById = async (id) => {
  const repair = await repairRepository.getRepairById(id);

  if (!repair) {
    throw new Error("Repair request not found.");
  }

  return repair;
};

// Get All Repairs
const getAllRepairs = async () => {
  return await repairRepository.getAllRepairs();
};

// Get Repairs By User
const getRepairsByUser = async (userId) => {
  return await repairRepository.getRepairsByUser(userId);
};

// Get Repairs By Product
const getRepairsByProduct = async (productId) => {
  return await repairRepository.getRepairsByProduct(productId);
};

// Update Repair
const updateRepair = async (id, data) => {
  const repair = await repairRepository.updateRepair(id, data);

  if (!repair) {
    throw new Error("Repair request not found.");
  }

  return repair;
};

// Update Repair Status
const updateRepairStatus = async (id, status) => {
  const repair = await repairRepository.updateRepairStatus(id, status);

  if (!repair) {
    throw new Error("Repair request not found.");
  }

  return repair;
};

// Mark Repair Delivered
const markDelivered = async (id) => {
  const repair = await repairRepository.markDelivered(id);

  if (!repair) {
    throw new Error("Repair request not found.");
  }

  return repair;
};

// Delete Repair
const deleteRepair = async (id) => {
  const repair = await repairRepository.deleteRepair(id);

  if (!repair) {
    throw new Error("Repair request not found.");
  }

  return repair;
};

module.exports = {
  createRepair,
  getRepairById,
  getAllRepairs,
  getRepairsByUser,
  getRepairsByProduct,
  updateRepair,
  updateRepairStatus,
  markDelivered,
  deleteRepair,
};